package com.capgemini.lab5.Service;

import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.lab5.Entity.Movie;
import com.capgemini.lab5.repository.MovieRepo;

@Service
public class MovieServices {

	@Autowired
	private MovieRepo movierepo;
	
	@Transactional
	public boolean addmovie(Movie movie)
	{
		return movierepo.save(movie) != null;
	}
	
	@Transactional
	public List<Movie> viewByGenre()
	{
		return movierepo.findAll();
	}
}

